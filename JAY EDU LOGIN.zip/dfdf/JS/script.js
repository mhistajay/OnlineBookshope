function showPage(pageId) {
// Hide all pagesconst pages = document.querySelectorAll('.page');
            pages.forEach(page => page.classList.remove('active'));
            
            // Show selected page
            document.getElementById(pageId).classList.add('active');
            
            // Clear any error/success messages
            document.querySelectorAll('.error-message, .success-message').forEach(msg => {
                msg.style.display = 'none';
            });
        }

        function togglePassword(fieldId) {
            const passwordInput = document.getElementById(fieldId);
            const toggleIcon = passwordInput.nextElementSibling;
            
            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                toggleIcon.textContent = '🙈';
            } else {
                passwordInput.type = 'password';
                toggleIcon.textContent = '👁️';
            }
        }

        function showError(elementId, message) {
            const errorDiv = document.getElementById(elementId);
            errorDiv.textContent = message;
            errorDiv.style.display = 'block';
        }

        function showSuccess(elementId, message) {
            const successDiv = document.getElementById(elementId);
            successDiv.textContent = message;
            successDiv.style.display = 'block';
        }

        function logout() {
            if (confirm('Are you sure you want to logout?')) {
                showPage('loginPage');
                // Clear forms
                document.getElementById('studentLoginForm').reset();
                document.getElementById('studentSignupForm').reset();
            }
        }

        // Login Form Handler
        document.getElementById('studentLoginForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            const studentId = document.getElementById('studentId').value.trim(6);
            const password = document.getElementById('loginPassword').value;
            const loginButton = document.getElementById('loginButton');
            
            if (!studentId || !password) {
                showError('loginError', 'Please fill in all fields');
                return;
            }

            loginButton.textContent = 'Signing In...';
            
            setTimeout(() => {
                if ((studentId.toLowerCase() === 'stu2024001' || studentId === 'FO3/45/56') && password === 'student123') {
                    showSuccess('loginSuccess', 'Go to Home Page');
                    setTimeout(() => {
                        showPage('homePage');
                    }, 1500);
                } else {
                    showError('loginError', 'Invalid student ID or password. Please try again.');
                }
                loginButton.textContent = 'Sign In';
            }, 2000);
        });

        

       

